#include <stdio.h>
#include "udp.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "mfs.h"

#define BUFFER_SIZE (4096)
int fd;
int
main(int argc, char *argv[])
{
    if (argc < 3) {
	printf("Usage: server [portnum] [file-system-image]");
        exit(0);
    }
    int port = atoi(argv[1]);
    char *file_image = argv[2];
    printf("port %d file image %s \n",port,file_image);
    fd = open(file_image, O_RDWR);
	
    if (fd < 0) { 
        fd = creat(file_image, S_IRWXU);
	assert(fd > 0);
	check_t * check_point = malloc(sizeof(check_t));
	lseek(fd,sizeof(check_t), SEEK_SET);
        //create checkpoint and inode map
        int i = 0;
	for (i = 0; i < 64; i++) {
	    MFS_Stat_t *inode_arr = malloc(sizeof(MFS_Stat_t)*16);
	    check_point->ptr[i] =i*(sizeof(MFS_Stat_t)*16)+sizeof(check_t);
	    write(fd, inode_arr, sizeof(inode_arr));
	}
	check_point->end = check_point->ptr[63]+sizeof(MFS_Stat_t)*16;
	// initialize inode_arr
	lseek(fd, 0, SEEK_SET);
	write(fd, check_point,sizeof(check_t));
	// create file directory
	MFS_DirEnt_t *root = malloc(sizeof(MFS_DirEnt_t));
        root->inum = 0;
        root->name[60] = ".";
	//update its inode, then write to file
	MFS_Stat_t * root_node = malloc(sizeof(MFS_Stat_t));
	root_node->type = MFS_DIRECTORY;
	root_node->size = sizeof(MFS_DirEnt_t);
	i = 0;
 	for(i = 0; i < 14; i ++ ) 
	   root_node->ptr[i] = -1;
	
	// write the inode
        lseek(fd, 0, SEEK_SET);
	check_t *check = malloc(sizeof(check_t));
        read(fd, check, sizeof(check_t));
	int offset = check->ptr[0];
	root_node->ptr[0] = check->end;
	lseek(fd, offset,SEEK_SET);
	write(fd, root_node, sizeof(MFS_Stat_t)); 
   	
 	// write the root directory
	lseek(fd, check->end, SEEK_SET);
	write(fd, root,sizeof(MFS_DirEnt_t)); 

	// update the checkpoint region
	check->end += sizeof(MFS_DirEnt_t);
	lseek(fd,0,SEEK_SET);
	write(fd, check, sizeof(check_t));
   }


    int sd = UDP_Open(port);
    assert(sd > -1);

    printf("SERVER:: waiting in loop\n");

    while (1) {
	struct sockaddr_in s;
	char buffer[BUFFER_SIZE];
	int rc = UDP_Read(sd, &s, buffer, BUFFER_SIZE);
	if (rc > 0) {
	    printf("  SERVER:: read %d bytes (message: '%s')\n", rc, buffer);	    
	    char reply[BUFFER_SIZE];
	    sprintf(reply, "reply");
	    rc = UDP_Write(sd, &s, reply, BUFFER_SIZE);
	}
    }

    return 0;
}

int lookup(int pinum, char *name) {
    int i_arr  = pinum /64;
    lseek(fd, 0, SEEK_SET);
    check_t *check = malloc(sizeof(check_t));
    read(fd, check, sizeof(check_t));
    int offset = check->ptr[i_arr];
    offset += (pinum % 16)*sizeof(MFS_Stat_t); // parent inode location
    lseek(fd, offset, SEEK_SET);
    MFS_Stat_t *parent = malloc(sizeof(MFS_Stat_t));
    read(fd, parent, sizeof(MFS_Stat_t));
    int i;
    for( i = 0; i < 14; i++) {
	MFS_DirEnt_t * child = malloc(sizeof(MFS_DirEnt_t));
	lseek(fd, parent->ptr[i], SEEK_SET);
	read(fd, child,4096);

    }
   

    
}
