
#ifndef __MESSAGE_h__
#define __MESSAGE_h__
#include "mfs.h"



#endif // __Message_h__
